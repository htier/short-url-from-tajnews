<?php
/**
 * Plugin Name: Short URL from TajNews
 * Plugin URI:  https://tajnews.org/short-url-from-tajnews/
 * Description: Automatically create and display short URLs using YOURLS. Works out of the box with g00g.link and a default signature, but allows overriding via plugin settings.
 * Version:     1.3
 * Author:      TajNews
 * Author URI:  https://g00g.link/
 * License:     GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: short-url-from-tajnews
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // No direct access
}

/* ----------------------------------------------------------------------
 * 1. Register settings for YOURLS domain & signature
 * -------------------------------------------------------------------- */
function tajnews_shorturl_register_settings() {
    register_setting( 'tajnews_shorturl_options_group', 'tajnews_shorturl_domain' );
    register_setting( 'tajnews_shorturl_options_group', 'tajnews_shorturl_signature' );
}
add_action('admin_init', 'tajnews_shorturl_register_settings');

function tajnews_shorturl_settings_menu() {
    add_options_page(
        'TajNews ShortURL Settings',
        'TajNews ShortURL',
        'manage_options',
        'tajnews-shorturl-settings',
        'tajnews_shorturl_settings_page'
    );
}
add_action('admin_menu', 'tajnews_shorturl_settings_menu');

/**
 * 1.1. Settings page content
 */
function tajnews_shorturl_settings_page() {
    if ( ! current_user_can('manage_options') ) {
        return;
    }

    $domain    = get_option('tajnews_shorturl_domain', '');
    $signature = get_option('tajnews_shorturl_signature', '');
    ?>
    <div class="wrap">
        <h1>TajNews ShortURL Settings</h1>
        
        <div style="margin-bottom: 20px; padding: 15px; background: #f8f8f8; border: 1px solid #ddd;">
            <h2>About this Plugin</h2>
            <p>
                <strong>Short URL from TajNews</strong> was initially created for our personal use, using the default domain <code>g00g.link</code> and signature key <em>(0d05ed4311)</em>. However, due to high demand and because many link-shortening solutions are expensive or limited, we decided to make our plugin publicly available <strong>for free</strong>.
            </p>
            <p>
                By default, the plugin operates in <em>automatic mode</em> with our YOURLS server. If you prefer using your own YOURLS domain and key, simply change the fields below and click "Save Changes".
            </p>

            <h3>Shortcode Usage</h3>
            <p>
                To display the short link <em>manually</em> in your post or page, use the shortcode:
                <br><code>[tajnews_shortlink]</code><br>
                This will output the generated short URL along with a "Copy" link.
            </p>

            <h3>Bookmarklets & Prefix Shortening</h3>
            <p>
                YOURLS provides handy bookmarklets for easier link shortening and sharing:
                <ul style="list-style: disc; margin-left: 20px;">
                    <li><strong>Standard bookmarklet:</strong> opens a page where you can edit or delete your short URLs.</li>
                    <li><strong>Instant bookmarklet:</strong> tries to show a popup with the short URL without leaving the current page.</li>
                    <li><strong>Simple or Advanced:</strong> either create a random short URL or choose your own custom keyword.</li>
                </ul>
                Drag these bookmarklets from your YOURLS admin panel to your browser's bookmarks toolbar.
            </p>
            <p>
                <strong>Prefix-based Shortening:</strong> If you’re viewing a page at <code>http://some-long-site.com/path</code>, you can simply add <code>g00g.link/</code> before <em>http://</em> in the address bar (like <code>g00g.link/http://some-long-site.com/path</code>) and press Enter to instantly create a short URL. Note that it may not work on Windows-hosted YOURLS servers or certain setups.
            </p>
            
            <h3>Safe API Calls (Signature)</h3>
            <p>
                Instead of sending username/password, YOURLS allows using a secret signature token (<em>0d05ed4311</em>) for API requests. This plugin relies on that approach to keep your login credentials secure. For time-limited signatures, you can pass <code>signature</code> and <code>timestamp</code> parameters, making the link valid only for a specified duration.
            </p>

            <h3>How to Use Your Own Domain & Key</h3>
            <ol style="list-style: decimal; margin-left: 20px;">
                <li>Install and configure YOURLS on your own hosting, for example: <code>https://short.example.com</code>.</li>
                <li>Get your <strong>Signature Key</strong> from the YOURLS admin area.</li>
                <li>Enter that domain and signature key in the fields below. (Leave them blank to keep using <code>g00g.link</code> and <em>0d05ed4311</em>.)</li>
                <li>Click <strong>Save Changes</strong>. Now every new published post will have a short link from your YOURLS server.</li>
            </ol>
        </div>

        <form method="post" action="options.php">
            <?php
            settings_fields('tajnews_shorturl_options_group');
            do_settings_sections('tajnews_shorturl_options_group');
            ?>
            <table class="form-table">
                <tr>
                    <th><label for="tajnews_shorturl_domain">YOURLS Domain:</label></th>
                    <td>
                        <input type="text" id="tajnews_shorturl_domain" name="tajnews_shorturl_domain"
                               value="<?php echo esc_attr($domain); ?>"
                               size="50" placeholder="https://example.com" />
                        <p class="description">
                            Enter your YOURLS domain (with http/https, no trailing slash). Leave blank to use <code>g00g.link</code>.
                        </p>
                    </td>
                </tr>
                <tr>
                    <th><label for="tajnews_shorturl_signature">Signature Key:</label></th>
                    <td>
                        <input type="text" id="tajnews_shorturl_signature" name="tajnews_shorturl_signature"
                               value="<?php echo esc_attr($signature); ?>"
                               size="50" placeholder="yourlsAPIkey123" />
                        <p class="description">
                            The secret signature for YOURLS API requests. Leave blank to use <code>0d05ed4311</code>.
                        </p>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

/* ----------------------------------------------------------------------
 * 2. Create short link via YOURLS API with fallback to g00g.link
 * -------------------------------------------------------------------- */
function tajnews_create_shortlink($long_url) {
    // Get user-defined or fallback to your domain/key
    $domain    = get_option('tajnews_shorturl_domain', '');
    $signature = get_option('tajnews_shorturl_signature', '');

    // Default (TajNews) domain & signature
    if ( empty($domain) ) {
        $domain = 'https://g00g.link'; // your domain
    }
    if ( empty($signature) ) {
        $signature = '0d05ed4311';     // your signature
    }

    $api_url = rtrim($domain, '/') . '/yourls-api.php';
    $response = wp_remote_post($api_url, array(
        'body' => array(
            'signature' => $signature,
            'action'    => 'shorturl',
            'format'    => 'json',
            'url'       => $long_url,
        ),
        'timeout' => 10,
    ));

    if ( is_wp_error($response) ) {
        return false;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if ( isset($data['shorturl']) ) {
        return $data['shorturl'];
    }
    return false;
}

/* ----------------------------------------------------------------------
 * 3. Auto-generate a short link when publishing a post
 * -------------------------------------------------------------------- */
function tajnews_autoshortlink_on_publish($post_id) {
    if ( wp_is_post_revision($post_id) ) {
        return;
    }

    // Avoid duplicate generation
    $existing_short = get_post_meta($post_id, '_tajnews_shortlink', true);
    if ( ! empty($existing_short) ) {
        return;
    }

    $long_url  = get_permalink($post_id);
    $short_url = tajnews_create_shortlink($long_url);
    if ( $short_url ) {
        update_post_meta($post_id, '_tajnews_shortlink', $short_url);
    }
}
add_action('publish_post', 'tajnews_autoshortlink_on_publish');

/* ----------------------------------------------------------------------
 * 4. Shortcode [tajnews_shortlink]: outputs short link + "Copy" button
 * -------------------------------------------------------------------- */
function tajnews_shortlink_shortcode() {
    $post_id = get_the_ID();
    if ( ! $post_id ) {
        return '';
    }

    $short_url = get_post_meta($post_id, '_tajnews_shortlink', true);
    if ( ! empty($short_url) ) {
        ob_start(); ?>
        <div class="tajnews-shortlink-box">
            <strong>Short URL:</strong>
            <span style="margin-left: 10px;"><?php echo esc_html($short_url); ?></span>
            <a href="#" style="margin-left: 10px;"
               onclick="tajnewsCopyShortLink('<?php echo esc_js($short_url); ?>'); return false;">
               Copy
            </a>
        </div>
        <?php
        return ob_get_clean();
    }
    return '';
}
add_shortcode('tajnews_shortlink', 'tajnews_shortlink_shortcode');

/* ----------------------------------------------------------------------
 * 5. Meta box: displays short link in post editor (click = copy + open)
 * -------------------------------------------------------------------- */
function tajnews_add_meta_box() {
    add_meta_box(
        'tajnews_shortlink_box',
        'TajNews Short URL',
        'tajnews_render_meta_box',
        'post',
        'side',
        'low'
    );
}
add_action('add_meta_boxes', 'tajnews_add_meta_box');

function tajnews_render_meta_box($post) {
    $short_url = get_post_meta($post->ID, '_tajnews_shortlink', true);
    if ( ! empty($short_url) ) {
        ?>
        <p><strong>Short URL:</strong></p>
        <p>
            <a href="<?php echo esc_url($short_url); ?>"
               onclick="tajnewsCopyShortLink('<?php echo esc_js($short_url); ?>'); return false;"
               target="_blank">
               <?php echo esc_html($short_url); ?>
            </a>
        </p>
        <?php
    } else {
        echo '<p>No short link yet (it will appear after publishing).</p>';
    }
}

/* ----------------------------------------------------------------------
 * 6. Automatically append short link at the bottom of the post
 * -------------------------------------------------------------------- */
add_filter('the_content', 'tajnews_append_shortlink_at_bottom');
function tajnews_append_shortlink_at_bottom($content) {
    if ( is_singular('post') && in_the_loop() && is_main_query() ) {
        $post_id   = get_the_ID();
        $short_url = get_post_meta($post_id, '_tajnews_shortlink', true);

        if ( ! empty($short_url) ) {
            $html  = '<div class="tajnews-shortlink-box" style="margin-top: 20px; padding: 10px; border-top: 1px solid #ddd;">';
            $html .= '<strong>Short URL:</strong> ';
            $html .= '<span style="margin-left: 10px;">' . esc_html($short_url) . '</span>';
            $html .= '<a href="#" style="margin-left: 10px;" onclick="tajnewsCopyShortLink(\'' . esc_js($short_url) . '\'); return false;">Copy</a>';
            $html .= '</div>';

            $content .= $html;
        }
    }
    return $content;
}

/* ----------------------------------------------------------------------
 * 7. JavaScript for "Copy to clipboard"
 * -------------------------------------------------------------------- */
add_action('wp_footer', 'tajnews_copy_script');
function tajnews_copy_script() {
    if ( is_singular('post') ) {
        ?>
        <script>
        function tajnewsCopyShortLink(url) {
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(url).then(function() {
                    alert('Link copied: ' + url);
                }, function(err) {
                    alert('Copy error: ' + err);
                });
            } else {
                // Fallback for older browsers
                var textArea = document.createElement('textarea');
                textArea.value = url;
                textArea.style.position = 'fixed';
                textArea.style.left = '-999999px';
                document.body.appendChild(textArea);
                textArea.focus();
                textArea.select();
                try {
                    if (document.execCommand('copy')) {
                        alert('Link copied: ' + url);
                    } else {
                        alert('Could not copy the link automatically.');
                    }
                } catch (e) {
                    alert('Copy exception: ' + e);
                }
                textArea.remove();
            }
        }
        </script>
        <?php
    }
}
